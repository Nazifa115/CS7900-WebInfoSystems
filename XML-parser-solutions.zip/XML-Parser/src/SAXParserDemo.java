import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXParserDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			 
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();
		 
			DefaultHandler handler = new DefaultHandler() {
		 
			boolean bname = false;
			boolean bprice = false;
			boolean bdescription = false;
			boolean bcalories = false;
			boolean bday = false;
		 
			public void startElement(String uri, String localName,String qName, 
		                Attributes attributes) throws SAXException {
		 
//				System.out.println("Start Element :" + qName);
				
				if (qName.equalsIgnoreCase("name")) {
					bname = true;
				}
		 
				if (qName.equalsIgnoreCase("price")) {
					System.out.println(attributes.getValue("currency"));
					bprice = true;
				}
		 
				if (qName.equalsIgnoreCase("description")) {
					bdescription = true;
				}
		 
				if (qName.equalsIgnoreCase("calories")) {
					bcalories = true;
				}
				
				if (qName.equalsIgnoreCase("day")) {
					bday = true;
				}
		 
			}
		 
			public void endElement(String uri, String localName,
				String qName) throws SAXException {
		 
//				System.out.println("End Element :" + qName);
		 
			}
		 
			public void characters(char ch[], int start, int length) throws SAXException {
		 
				if (bname) {
					System.out.println("Name : " + new String(ch, start, length));
					bname = false;
				}
		 
				if (bprice) {
					System.out.println("Price : " + new String(ch, start, length));
					bprice = false;
				}
		 
				if (bdescription) {
					System.out.println("Description : " + new String(ch, start, length));
					bdescription = false;
				}
		 
				if (bcalories) {
					System.out.println("Calories : " + new String(ch, start, length));
					bcalories = false;
				}
				
				if (bday) {
					System.out.println("Day : " + new String(ch, start, length));
					bday = false;
				}
				
			}
		 
		     };
		 
		       saxParser.parse("docs/simple.xml", handler);
		 
		     } catch (Exception e) {
		       e.printStackTrace();
		     }

	}

}
